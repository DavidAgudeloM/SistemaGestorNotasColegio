package app;

public class Profesor extends Persona {
    public Profesor(String nombre) { super(nombre); }
}
