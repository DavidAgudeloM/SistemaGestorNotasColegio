package colegio;

public interface IPersona {
    String getId();
    String getNombre();
    String getApellido();
    String getDescripcion();
}
