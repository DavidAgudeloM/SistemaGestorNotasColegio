package colegio;

public class Main {
    public static void main(String[] args) {
        SistemaColegio sistema = SistemaColegio.getInstancia();
        sistema.iniciarMenu();
    }
}
