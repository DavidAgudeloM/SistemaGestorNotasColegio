package colegio;

import java.util.List;

public interface EstrategiaNota {
    double calcular(List<Double> notas);
}
